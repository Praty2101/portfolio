import { motion } from 'framer-motion';

export default function About() {
  const skills = [
    { name: 'Machine Learning', level: 95 },
    { name: 'Deep Learning', level: 90 },
    { name: 'Computer Vision', level: 85 },
    { name: 'Natural Language Processing', level: 88 },
    { name: 'Data Analysis', level: 92 },
    { name: 'Python', level: 95 },
    { name: 'TensorFlow/PyTorch', level: 90 },
    { name: 'Research Methodology', level: 87 },
  ];

  return (
    <section id="about" className="py-20">
      <div className="content-container">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="section-title">About Me</h2>
        </motion.div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            <div className="relative">
              <div className="aspect-square w-[240px] mx-auto overflow-hidden rounded-full bg-[#161618] flex items-center justify-center border-4 border-[#1e1e20]">
                <img 
                  src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&auto=format&fit=crop&q=80" 
                  alt="Portrait" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -right-6 bg-[#0f0f10] p-3 rounded-xl shadow-lg">
                <span className="gradient-text text-xl font-bold">5+ Years</span>
                <p className="text-sm text-gray-400">Research Experience</p>
              </div>
            </div>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="flex flex-col justify-center"
          >
            <h3 className="text-2xl font-bold mb-4">
              An AI/ML Researcher with passion for solving complex problems
            </h3>
            
            <p className="text-gray-300 mb-6">
              I specialize in developing cutting-edge machine learning models and algorithms 
              that push the boundaries of artificial intelligence. With a background in 
              computer science and mathematics, I bring a unique perspective to AI research 
              and development.
            </p>
            
            <p className="text-gray-300 mb-8">
              My research focuses on improving model interpretability, efficiency, and 
              robustness. I'm passionate about creating AI solutions that are not only 
              technically advanced but also ethical and beneficial to society.
            </p>
            
            <div className="mt-4">
              <a href="#dashboard" className="btn btn-primary inline-flex items-center">
                View Skills Dashboard
                <svg className="ml-2 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
                </svg>
              </a>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
